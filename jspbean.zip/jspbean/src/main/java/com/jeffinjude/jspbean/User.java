package com.jeffinjude.jspbean;

public class User {
	private String fname;
	private String lname;
	private String rollno;
	private String address;
	
	public User() {
		this.fname = "testfname";
		this.lname = "testlname";
		this.rollno = "testroll";
		this.address = "testaddr";
	}
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
